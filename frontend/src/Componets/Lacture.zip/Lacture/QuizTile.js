import "./QuizTile.css";

function QuizTile(){
    return(
        <div class="Tile">
            <div class="tile">

            </div>
            <div Clas="Course">

            </div>


        </div>

        
        
    )
}

export default QuizTile;